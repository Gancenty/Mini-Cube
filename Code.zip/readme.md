# 代码开发环境
## VScode + PlatformIO插件
### 使用VScode 打开Code文件夹等待插件配置好项目文件